package package1;

import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Toolkit;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JSeparator;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EntryPage {

	private JFrame frmMyCaffeHub;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EntryPage window = new EntryPage();
					window.frmMyCaffeHub.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public EntryPage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMyCaffeHub = new JFrame();
		frmMyCaffeHub.setIconImage(Toolkit.getDefaultToolkit().getImage(EntryPage.class.getResource("/Images/Coffeelogo.png")));
		frmMyCaffeHub.setTitle("My Caffe Hub Entry Page");
		//Toolkit kit = Toolkit.getDefaultToolkit();
		//Dimension screenSize = kit.getScreenSize();
		//int width = screenSize.width;
		//int height = screenSize.height;
		//frmMyCaffeHub.setSize(width, height);
		//frmMyCaffeHub.setLocationRelativeTo(null);
		frmMyCaffeHub.setBounds(100, 100, 1000, 655);
		frmMyCaffeHub.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMyCaffeHub.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("My CaFFe Hub");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(147, 112, 219));
		lblNewLabel.setFont(new Font("Consolas", Font.BOLD, 50));
		lblNewLabel.setBounds(208, 31, 615, 60);
		frmMyCaffeHub.getContentPane().add(lblNewLabel);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(624, 99, -554, 12);
		frmMyCaffeHub.getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(119, 101, 746, 16);
		frmMyCaffeHub.getContentPane().add(separator_1);
		
		JButton btnAdminLogin = new JButton("Admin Login");
		btnAdminLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Loginform.main(null);
			}
		});
		btnAdminLogin.setForeground(new Color(255, 105, 180));
		btnAdminLogin.setFont(new Font("Consolas", Font.BOLD, 22));
		btnAdminLogin.setBounds(183, 174, 210, 94);
		frmMyCaffeHub.getContentPane().add(btnAdminLogin);
		
		JButton btnCustomerLogin = new JButton("Customer Login");
		btnCustomerLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CustomerLoginform.main(null);
			}
		});
		btnCustomerLogin.setForeground(new Color(210, 105, 30));
		btnCustomerLogin.setFont(new Font("Consolas", Font.BOLD, 22));
		btnCustomerLogin.setBounds(613, 174, 210, 94);
		frmMyCaffeHub.getContentPane().add(btnCustomerLogin);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMyCaffeHub.setVisible(false);
			}
		});
		btnBack.setForeground(new Color(0, 128, 0));
		btnBack.setFont(new Font("Consolas", Font.BOLD, 24));
		btnBack.setBounds(86, 473, 134, 53);
		frmMyCaffeHub.getContentPane().add(btnBack);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setForeground(new Color(0, 128, 0));
		btnExit.setFont(new Font("Consolas", Font.BOLD, 24));
		btnExit.setBounds(779, 473, 134, 53);
		frmMyCaffeHub.getContentPane().add(btnExit);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(119, 384, 746, 12);
		frmMyCaffeHub.getContentPane().add(separator_2);
	}
}
