package package1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CustomerLoginform {

	private JFrame frmCafe;
	private JTextField txtUsername;
	private JPasswordField txtpassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerLoginform window = new CustomerLoginform();
					window.frmCafe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CustomerLoginform() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmCafe = new JFrame();
		frmCafe.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 19));
		frmCafe.getContentPane().setForeground(Color.BLUE);
		frmCafe.setIconImage(Toolkit.getDefaultToolkit().getImage(Loginform.class.getResource("/Images/Coffeelogo.png")));
		frmCafe.setTitle("My Caffe Hub");
		frmCafe.setBounds(100, 100, 1000, 655);
		frmCafe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmCafe.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel(" My CaFFe Hub");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(147, 112, 219));
		lblNewLabel.setFont(new Font("Consolas", Font.BOLD, 45));
		lblNewLabel.setBounds(216, 20, 537, 54);
		frmCafe.getContentPane().add(lblNewLabel);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(105, 140, 744, 23);
		frmCafe.getContentPane().add(separator);
		
		JLabel lblNewLabel_1 = new JLabel("User Name:");
		lblNewLabel_1.setFont(new Font("Consolas", Font.BOLD, 24));
		lblNewLabel_1.setBounds(126, 210, 147, 54);
		frmCafe.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password:");
		lblNewLabel_2.setFont(new Font("Consolas", Font.BOLD, 24));
		lblNewLabel_2.setBounds(141, 311, 132, 47);
		frmCafe.getContentPane().add(lblNewLabel_2);
		
		txtUsername = new JTextField();
		txtUsername.setFont(new Font("Tahoma", Font.PLAIN, 18));
		txtUsername.setBounds(303, 207, 475, 57);
		frmCafe.getContentPane().add(txtUsername);
		txtUsername.setColumns(10);
		
		txtpassword = new JPasswordField();
		txtpassword.setFont(new Font("Tahoma", Font.PLAIN, 24));
		txtpassword.setBounds(303, 305, 475, 53);
		frmCafe.getContentPane().add(txtpassword);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(105, 406, 744, 23);
		frmCafe.getContentPane().add(separator_1);
		
		JButton btnLogin = new JButton("Login & Order");
		btnLogin.setForeground(new Color(0, 128, 0));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String username = txtUsername.getText();
				String password = txtpassword.getText();
				
				//System.out.println(username + password);
				
				if(username.equals("amol") && password.equals("111")) {
					//System.out.println("Valid user");
					
					CustomerPage.main(null);
					JOptionPane.showMessageDialog(null, "Login Successfull");
					CustomerPage.main(null);
				}
				else {
					JOptionPane.showMessageDialog(null, "Invalid Username Or Password");
					
				}
			}
		});
		btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnLogin.setBounds(46, 476, 178, 54);
		frmCafe.getContentPane().add(btnLogin);
		
		JButton btnReset = new JButton("Reset");
		btnReset.setForeground(new Color(0, 128, 0));
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtUsername.setText(null);
				txtpassword.setText(null);
				
			}
		});
		btnReset.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnReset.setBounds(540, 475, 147, 57);
		frmCafe.getContentPane().add(btnReset);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setForeground(new Color(0, 128, 0));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnExit.setBounds(748, 475, 147, 57);
		frmCafe.getContentPane().add(btnExit);
		
		JButton btnReset_1 = new JButton("Back");
		btnReset_1.setForeground(new Color(0, 128, 0));
		btnReset_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmCafe.setVisible(false);
			}
		});
		btnReset_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnReset_1.setBounds(312, 475, 147, 57);
		frmCafe.getContentPane().add(btnReset_1);
		
		JLabel lblHeyyFooodies = new JLabel("WEL - COME");
		lblHeyyFooodies.setHorizontalAlignment(SwingConstants.CENTER);
		lblHeyyFooodies.setForeground(new Color(154, 205, 50));
		lblHeyyFooodies.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 35));
		lblHeyyFooodies.setBounds(316, 74, 351, 47);
		frmCafe.getContentPane().add(lblHeyyFooodies);
	}
}
