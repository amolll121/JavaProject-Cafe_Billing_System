package package1;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;

public class ViewOrders {
	  
	Connection con = null;
	PreparedStatement pstmt = null;
	private JFrame MyCaffeHub;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ViewOrders window = new ViewOrders();
					window.MyCaffeHub.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ViewOrders() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		MyCaffeHub = new JFrame();
		MyCaffeHub.setIconImage(Toolkit.getDefaultToolkit().getImage(MainPagecaffe.class.getResource("/Images/Coffeelogo.png")));
		MyCaffeHub.setTitle("My Caffe Hub");
		MyCaffeHub.setBounds(100, 100, 1320, 768);
		MyCaffeHub.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		MyCaffeHub.getContentPane().setLayout(null);
		
		JLabel ViewBills = new JLabel("Orders");
		ViewBills.setHorizontalAlignment(SwingConstants.CENTER);
		ViewBills.setForeground(new Color(210, 105, 30));
		ViewBills.setFont(new Font("Segoe Print", Font.BOLD, 28));
		ViewBills.setBounds(529, 33, 252, 63);
		MyCaffeHub.getContentPane().add(ViewBills);
		
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(122, 613, 1061, 21);
		MyCaffeHub.getContentPane().add(separator_1);
		
		JSeparator separator_1_1 = new JSeparator();
		separator_1_1.setBounds(122, 613, 1061, 21);
		MyCaffeHub.getContentPane().add(separator_1_1);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MyCaffeHub.setVisible(false);
			}
		});
		btnBack.setForeground(new Color(0, 128, 0));
		btnBack.setFont(new Font("Consolas", Font.BOLD, 24));
		btnBack.setBounds(71, 640, 134, 53);
		MyCaffeHub.getContentPane().add(btnBack);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setForeground(new Color(0, 128, 0));
		btnExit.setFont(new Font("Consolas", Font.BOLD, 24));
		btnExit.setBounds(1093, 640, 134, 53);
		MyCaffeHub.getContentPane().add(btnExit);
		
		JButton btnViewOrders = new JButton("View Orders");
		btnViewOrders.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");

					System.out.println("Got the Driver");

					} catch (ClassNotFoundException e1) { 

					e1.printStackTrace();

					System.out.println("Problem in loading Driver");
					}
					try 
					{ con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cafedatabase", "root","Amol2101"); 
					System.out.println("Connected");
					
					String sql = "Select * from caffe";
					
					PreparedStatement pst = con.prepareStatement(sql);
					
					ResultSet rs = pst.executeQuery();
					
					table.setModel(DbUtils.resultSetToTableModel(rs) );
					
					} catch (SQLException e2) {
						e2.printStackTrace(); 
						System.out.println("Problem in connection");
			}
				
				
			}
		});
		btnViewOrders.setForeground(new Color(220, 20, 60));
		btnViewOrders.setFont(new Font("Consolas", Font.BOLD, 26));
		btnViewOrders.setBounds(545, 644, 252, 63);
		MyCaffeHub.getContentPane().add(btnViewOrders);
		
		JSeparator separator_1_2 = new JSeparator();
		separator_1_2.setBounds(122, 106, 1061, 21);
		MyCaffeHub.getContentPane().add(separator_1_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(122, 129, 1041, 388);
		MyCaffeHub.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setForeground(new Color(0, 0, 0));
		
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Name", "Address", "Mobile No.", "Food Item", "Quantity"
			}
		));
		scrollPane.setViewportView(table);
		
	}
}
