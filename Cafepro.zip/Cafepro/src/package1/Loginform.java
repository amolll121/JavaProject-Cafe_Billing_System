package package1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Loginform {

	private JFrame frmCafe;
	private JTextField txtUsername;
	private JPasswordField txtpassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Loginform window = new Loginform();
					window.frmCafe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Loginform() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmCafe = new JFrame();
		frmCafe.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 19));
		frmCafe.getContentPane().setForeground(Color.BLUE);
		frmCafe.setIconImage(Toolkit.getDefaultToolkit().getImage(Loginform.class.getResource("/Images/Coffeelogo.png")));
		frmCafe.setTitle("My Caffe Hub");
		frmCafe.setBounds(100, 100, 1000, 655);
		frmCafe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmCafe.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel(" My CaFFe Hub");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(147, 112, 219));
		lblNewLabel.setFont(new Font("Consolas", Font.BOLD, 45));
		lblNewLabel.setBounds(216, 10, 537, 54);
		frmCafe.getContentPane().add(lblNewLabel);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(105, 140, 744, 23);
		frmCafe.getContentPane().add(separator);
		
		JLabel lblNewLabel_1 = new JLabel("User Name:");
		lblNewLabel_1.setFont(new Font("Consolas", Font.BOLD, 22));
		lblNewLabel_1.setBounds(141, 210, 132, 54);
		frmCafe.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password:");
		lblNewLabel_2.setFont(new Font("Consolas", Font.BOLD, 22));
		lblNewLabel_2.setBounds(141, 311, 132, 47);
		frmCafe.getContentPane().add(lblNewLabel_2);
		
		txtUsername = new JTextField();
		txtUsername.setFont(new Font("Tahoma", Font.PLAIN, 18));
		txtUsername.setBounds(303, 207, 475, 57);
		frmCafe.getContentPane().add(txtUsername);
		txtUsername.setColumns(10);
		
		txtpassword = new JPasswordField();
		txtpassword.setFont(new Font("Tahoma", Font.PLAIN, 24));
		txtpassword.setBounds(303, 305, 475, 53);
		frmCafe.getContentPane().add(txtpassword);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(105, 397, 744, 23);
		frmCafe.getContentPane().add(separator_1);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setForeground(new Color(0, 128, 0));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String username = txtUsername.getText();
				String password = txtpassword.getText();
				
				//System.out.println(username + password);
				
				if(username.equals("admin") && password.equals("admin")) {
					//System.out.println("Valid user");
					JOptionPane.showMessageDialog(null, "Login Successfull");
					AdminPage.main(null);
				}
				else {
					JOptionPane.showMessageDialog(null, "Invalid Username Or Password");
					
				}
			}
		});
		btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnLogin.setBounds(86, 475, 147, 57);
		frmCafe.getContentPane().add(btnLogin);
		
		JButton btnReset = new JButton("Reset");
		btnReset.setForeground(new Color(0, 128, 0));
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtUsername.setText(null);
				txtpassword.setText(null);
				
			}
		});
		btnReset.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnReset.setBounds(540, 475, 147, 57);
		frmCafe.getContentPane().add(btnReset);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setForeground(new Color(0, 128, 0));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnExit.setBounds(748, 475, 147, 57);
		frmCafe.getContentPane().add(btnExit);
		
		JButton btnReset_1 = new JButton("Back");
		btnReset_1.setForeground(new Color(0, 128, 0));
		btnReset_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmCafe.setVisible(false);
			}
		});
		btnReset_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnReset_1.setBounds(312, 475, 147, 57);
		frmCafe.getContentPane().add(btnReset_1);
		
		JLabel lblHeyyAdmin = new JLabel("*\"ADMIN\"*");
		lblHeyyAdmin.setHorizontalAlignment(SwingConstants.CENTER);
		lblHeyyAdmin.setForeground(new Color(178, 34, 34));
		lblHeyyAdmin.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 35));
		lblHeyyAdmin.setBounds(216, 76, 537, 54);
		frmCafe.getContentPane().add(lblHeyyAdmin);
	}
}
