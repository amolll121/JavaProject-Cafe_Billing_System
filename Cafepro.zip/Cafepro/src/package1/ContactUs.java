package package1;

import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JSeparator;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ContactUs {

	private JFrame frmMyCaffeHub;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ContactUs window = new ContactUs();
					window.frmMyCaffeHub.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ContactUs() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMyCaffeHub = new JFrame();
		frmMyCaffeHub.getContentPane().setForeground(new Color(178, 34, 34));
		frmMyCaffeHub.setIconImage(Toolkit.getDefaultToolkit().getImage(MainPagecaffe.class.getResource("/Images/Coffeelogo.png")));
		frmMyCaffeHub.setTitle("My Caffe Hub");
		frmMyCaffeHub.setBounds(100, 100, 1000, 655);
		frmMyCaffeHub.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMyCaffeHub.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Contact Us");
		lblNewLabel.setForeground(new Color(128, 0, 128));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 27));
		lblNewLabel.setBounds(368, 54, 272, 63);
		frmMyCaffeHub.getContentPane().add(lblNewLabel);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(47, 134, 870, 21);
		frmMyCaffeHub.getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(47, 499, 870, 21);
		frmMyCaffeHub.getContentPane().add(separator_1);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMyCaffeHub.setVisible(false);
			}
		});
		btnNewButton.setForeground(new Color(0, 128, 0));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 22));
		btnNewButton.setBounds(96, 530, 124, 54);
		frmMyCaffeHub.getContentPane().add(btnNewButton);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setForeground(new Color(0, 128, 0));
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 22));
		btnExit.setBounds(734, 530, 124, 54);
		frmMyCaffeHub.getContentPane().add(btnExit);
		
		JLabel lblNewLabel_1 = new JLabel("1. Rutwik Gunjal               9856565656   ");
		lblNewLabel_1.setForeground(new Color(210, 105, 30));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_1.setBounds(136, 165, 517, 54);
		frmMyCaffeHub.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("2.Mrunalini Shinde        9856565658   ");
		lblNewLabel_1_2.setForeground(new Color(199, 21, 133));
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_1_2.setBounds(136, 238, 517, 54);
		frmMyCaffeHub.getContentPane().add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("3. Amol Hokarne               9856565659    ");
		lblNewLabel_1_3.setForeground(new Color(0, 139, 139));
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_1_3.setBounds(136, 312, 517, 54);
		frmMyCaffeHub.getContentPane().add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_3_1 = new JLabel("Email : CRonaldo777@cristiano.com");
		lblNewLabel_1_3_1.setForeground(new Color(128, 0, 128));
		lblNewLabel_1_3_1.setFont(new Font("Tahoma", Font.BOLD, 21));
		lblNewLabel_1_3_1.setBounds(537, 435, 380, 54);
		frmMyCaffeHub.getContentPane().add(lblNewLabel_1_3_1);
		
		
	}
}
