package package1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Toolkit;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainPagecaffe {

	private JFrame frmMyCaffeHub;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainPagecaffe window = new MainPagecaffe();
					window.frmMyCaffeHub.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainPagecaffe() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMyCaffeHub = new JFrame();
		frmMyCaffeHub.setIconImage(Toolkit.getDefaultToolkit().getImage(MainPagecaffe.class.getResource("/Images/Coffeelogo.png")));
		frmMyCaffeHub.setTitle("My Caffe Hub");
		frmMyCaffeHub.setBounds(100, 100, 1000, 655);
		frmMyCaffeHub.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMyCaffeHub.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome");
		lblNewLabel.setForeground(new Color(255, 20, 147));
		lblNewLabel.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(365, 10, 217, 40);
		frmMyCaffeHub.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("To");
		lblNewLabel_1.setForeground(new Color(255, 140, 0));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		lblNewLabel_1.setBounds(431, 60, 67, 40);
		frmMyCaffeHub.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel(" 'My CaFFe Hub' ");
		lblNewLabel_2.setForeground(new Color(160, 82, 45));
		lblNewLabel_2.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 25));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(350, 110, 255, 40);
		frmMyCaffeHub.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(MainPagecaffe.class.getResource("/Images/coffe.jpg")));
		lblNewLabel_3.setBounds(29, 194, 451, 337);
		frmMyCaffeHub.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("New label");
		lblNewLabel_4.setIcon(new ImageIcon(MainPagecaffe.class.getResource("/Images/coffeslogad.jpg")));
		lblNewLabel_4.setBounds(710, 25, 167, 206);
		frmMyCaffeHub.getContentPane().add(lblNewLabel_4);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setForeground(new Color(255, 0, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EntryPage.main(null);
			}
		});
		btnNewButton.setFont(new Font("Consolas", Font.BOLD, 22));
		btnNewButton.setBounds(706, 322, 143, 50);
		frmMyCaffeHub.getContentPane().add(btnNewButton);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(529, 297, 398, -21);
		frmMyCaffeHub.getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(539, 265, 408, 11);
		frmMyCaffeHub.getContentPane().add(separator_1);
		
		JButton btnAboutUs = new JButton("About Us");
		btnAboutUs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AboutUs.main(null);
			}
		});
		btnAboutUs.setFont(new Font("Consolas", Font.BOLD, 22));
		btnAboutUs.setBounds(684, 402, 177, 56);
		frmMyCaffeHub.getContentPane().add(btnAboutUs);
		
		JButton btnNewButton_1_1 = new JButton("Contact Us");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ContactUs.main(null);
			}
		});
		btnNewButton_1_1.setForeground(new Color(219, 112, 147));
		btnNewButton_1_1.setFont(new Font("Consolas", Font.BOLD, 22));
		btnNewButton_1_1.setBounds(694, 481, 155, 50);
		frmMyCaffeHub.getContentPane().add(btnNewButton_1_1);
	}
}
