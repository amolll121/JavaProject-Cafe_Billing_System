package package1;

import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AdminPage {

	private JFrame frmMyCaffeHub;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminPage window = new AdminPage();
					window.frmMyCaffeHub.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AdminPage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMyCaffeHub = new JFrame();
		frmMyCaffeHub.setIconImage(Toolkit.getDefaultToolkit().getImage(MainPagecaffe.class.getResource("/Images/Coffeelogo.png")));
		frmMyCaffeHub.setTitle("My Caffe Hub");
		frmMyCaffeHub.setBounds(100, 100, 1000, 655);
		frmMyCaffeHub.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMyCaffeHub.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome Admin");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 0, 255));
		lblNewLabel.setFont(new Font("Microsoft Sans Serif", Font.BOLD, 30));
		lblNewLabel.setBounds(345, 36, 290, 71);
		frmMyCaffeHub.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("View Orders");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewOrders.main(null);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 22));
		btnNewButton.setForeground(new Color(205, 92, 92));
		btnNewButton.setBounds(348, 302, 290, 64);
		frmMyCaffeHub.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("View Bills");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Viewbills.main(null);
			}
		});
		btnNewButton_1.setForeground(new Color(205, 92, 92));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 22));
		btnNewButton_1.setBounds(348, 170, 290, 64);
		frmMyCaffeHub.getContentPane().add(btnNewButton_1);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(144, 117, 655, 21);
		frmMyCaffeHub.getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(144, 418, 655, 21);
		frmMyCaffeHub.getContentPane().add(separator_1);
		
		JButton btnNewButton_2 = new JButton("Back");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frmMyCaffeHub.setVisible(false);
			}
		});
		btnNewButton_2.setForeground(new Color(0, 100, 0));
		btnNewButton_2.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		btnNewButton_2.setBounds(92, 507, 125, 53);
		frmMyCaffeHub.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_2_1 = new JButton("Exit");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton_2_1.setForeground(new Color(0, 128, 0));
		btnNewButton_2_1.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		btnNewButton_2_1.setBounds(767, 507, 125, 53);
		frmMyCaffeHub.getContentPane().add(btnNewButton_2_1);
		
		JButton btnNewButton_3 = new JButton("LOGOUT");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EntryPage.main(null);
			}
		});
		btnNewButton_3.setFont(new Font("Sitka Small", Font.PLAIN, 20));
		btnNewButton_3.setForeground(new Color(153, 50, 204));
		btnNewButton_3.setBounds(821, 47, 125, 42);
		frmMyCaffeHub.getContentPane().add(btnNewButton_3);
	}
}
