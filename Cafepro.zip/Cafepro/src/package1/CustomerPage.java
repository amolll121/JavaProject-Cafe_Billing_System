package package1;

import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JOptionPane;

import net.proteanit.sql.DbUtils;

import javax.swing.JSeparator;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JRadioButton;
import javax.swing.JPanel;
import javax.swing.ButtonGroup;

public class CustomerPage {

	Connection con = null;
	PreparedStatement pstmt = null;
	private JFrame frmMyCaffeHb;
	private JTextField textField;
	private JTextField textField_1;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerPage window = new CustomerPage();
					window.frmMyCaffeHb.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	//private void clearFields()
	//{
	//	textField.setText(null);
		//textField_1.setText(null);
		
		
		
	//}

	/**
	 * Create the application.
	 */
	public CustomerPage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMyCaffeHb = new JFrame();
		frmMyCaffeHb.setIconImage(Toolkit.getDefaultToolkit().getImage(MainPagecaffe.class.getResource("/Images/Coffeelogo.png")));
		frmMyCaffeHb.setTitle("My Caffe Hub");
		frmMyCaffeHb.setBounds(100, 100, 1000, 655);
		frmMyCaffeHb.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMyCaffeHb.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Heyy,");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(128, 0, 128));
		lblNewLabel.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 28));
		lblNewLabel.setBounds(381, 10, 175, 33);
		frmMyCaffeHb.getContentPane().add(lblNewLabel);
		
		JLabel lblWelcomeToOur = new JLabel("Welcome to Our My CaFFe Hub");
		lblWelcomeToOur.setHorizontalAlignment(SwingConstants.CENTER);
		lblWelcomeToOur.setForeground(new Color(255, 69, 0));
		lblWelcomeToOur.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 28));
		lblWelcomeToOur.setBounds(221, 42, 526, 33);
		frmMyCaffeHb.getContentPane().add(lblWelcomeToOur);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(112, 122, 751, 13);
		frmMyCaffeHb.getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(112, 516, 751, 13);
		frmMyCaffeHb.getContentPane().add(separator_1);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMyCaffeHb.setVisible(false);;
			}
		});
		btnNewButton.setForeground(new Color(0, 128, 0));
		btnNewButton.setFont(new Font("Trebuchet MS", Font.BOLD, 22));
		btnNewButton.setBounds(57, 539, 132, 49);
		frmMyCaffeHb.getContentPane().add(btnNewButton);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		
				System.exit(0);
			}
			
		});
		btnExit.setForeground(new Color(0, 128, 0));
		btnExit.setFont(new Font("Trebuchet MS", Font.BOLD, 22));
		btnExit.setBounds(757, 537, 132, 53);
		frmMyCaffeHb.getContentPane().add(btnExit);
		
		JLabel Name_ = new JLabel("Name:");
		Name_.setFont(new Font("Tahoma", Font.BOLD, 18));
		Name_.setBounds(112, 145, 78, 40);
		frmMyCaffeHb.getContentPane().add(Name_);
		
		JLabel Phonenumber = new JLabel("Phone Number:");
		Phonenumber.setFont(new Font("Tahoma", Font.BOLD, 18));
		Phonenumber.setBounds(37, 220, 153, 40);
		frmMyCaffeHb.getContentPane().add(Phonenumber);
		
		JLabel Address = new JLabel("Address:");
		Address.setFont(new Font("Tahoma", Font.BOLD, 18));
		Address.setBounds(101, 290, 95, 40);
		frmMyCaffeHb.getContentPane().add(Address);
		
		JLabel Foods = new JLabel("Food Items:");
		Foods.setFont(new Font("Tahoma", Font.BOLD, 18));
		Foods.setBounds(68, 385, 111, 40);
		frmMyCaffeHb.getContentPane().add(Foods);
		
		textField = new JTextField();
		textField.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		textField.setBounds(221, 145, 451, 36);
		frmMyCaffeHb.getContentPane().add(textField);
		textField.setColumns(10);
		
		final JTextArea textAddress = new JTextArea();
		textAddress.setFont(new Font("Trebuchet MS", Font.BOLD, 18));
		textAddress.setBounds(220, 290, 452, 66);
		frmMyCaffeHb.getContentPane().add(textAddress);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 20));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Tea                                  Rs.10/-", "Hot Coffee                        Rs.30/-        ", "Cold Coffee                       Rs.30/-", "Cappuccino                      Rs.70/-", "Pizza                                Rs.129/-", "Burger                             Rs.79/-", "French Fries                      Rs.45/-"}));
		comboBox.setToolTipText("Tea\r\nHot Coffee\r\nCold Coffee\r\nCappucino\r\nPizza\r\nBurger \r\nFrench Fries\r\n");
		comboBox.setBounds(222, 384, 344, 40);
		frmMyCaffeHb.getContentPane().add(comboBox);
		
		JLabel quantity_ = new JLabel("Quantity:");
		quantity_.setFont(new Font("Tahoma", Font.BOLD, 18));
		quantity_.setBounds(86, 452, 112, 40);
		frmMyCaffeHb.getContentPane().add(quantity_);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5"}));
		comboBox_1.setBounds(220, 452, 63, 39);
		frmMyCaffeHb.getContentPane().add(comboBox_1);
		
		JButton btnPlaceOrder = new JButton("Place Order");
		btnPlaceOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(textField.getText().equals("")||textField_1.getText().equals("")||textAddress.getText().equals("")||comboBox.getSelectedItem().equals("")||comboBox_1.getSelectedItem().equals(""))
					
				{
					JOptionPane.showMessageDialog(null, "Fill All the details");
					
				}
				
				
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");

					System.out.println("Got the Driver");

					} catch (ClassNotFoundException e1) { 

					e1.printStackTrace();

					System.out.println("Problem in loading Driver");
					}
				
				
					try 
					{ con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cafedatabase", "root","Amol2101"); 
					System.out.println("Connected");
					
					String sql = "insert into caffe values(?,?,?,?,?)";
					
					PreparedStatement pst = con.prepareStatement(sql);
					
					pst.setString(1, textField.getText());
					pst.setString(2, textField_1.getText());
					pst.setString(3, textAddress.getText());
					pst.setString(4, (String) comboBox.getSelectedItem());
					pst.setString(5, (String) comboBox_1.getSelectedItem());
					
					
					
					pst.executeUpdate();
					
					JOptionPane.showMessageDialog(null, "Order Placed Successfully");
					//clearFields();
					con.close();
					
					
					
					
					} catch (SQLException e2) {
						e2.printStackTrace(); 
						System.out.println("Problem in connection");
			}
				
			}
		});
		btnPlaceOrder.setForeground(new Color(199, 21, 133));
		btnPlaceOrder.setFont(new Font("Trebuchet MS", Font.BOLD, 22));
		btnPlaceOrder.setBounds(369, 532, 221, 60);
		frmMyCaffeHb.getContentPane().add(btnPlaceOrder);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Trebuchet MS", Font.PLAIN, 22));
		textField_1.setColumns(10);
		textField_1.setBounds(220, 220, 452, 33);
		frmMyCaffeHb.getContentPane().add(textField_1);
		
		JLabel lblOrderYourFood = new JLabel("Order Your Food");
		lblOrderYourFood.setHorizontalAlignment(SwingConstants.CENTER);
		lblOrderYourFood.setForeground(new Color(0, 191, 255));
		lblOrderYourFood.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 28));
		lblOrderYourFood.setBounds(352, 79, 262, 33);
		frmMyCaffeHb.getContentPane().add(lblOrderYourFood);
		
		JLabel lblNewLabel_2 = new JLabel("Type:");
		lblNewLabel_2.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		lblNewLabel_2.setBounds(762, 162, 86, 33);
		frmMyCaffeHb.getContentPane().add(lblNewLabel_2);
		
		JPanel panel = new JPanel();
		panel.setBounds(733, 205, 192, 49);
		frmMyCaffeHb.getContentPane().add(panel);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Veg");
		buttonGroup.add(rdbtnNewRadioButton);
		buttonGroup.add(rdbtnNewRadioButton);
		panel.add(rdbtnNewRadioButton);
		rdbtnNewRadioButton.setForeground(new Color(154, 205, 50));
		rdbtnNewRadioButton.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		
		JRadioButton rdbtnNonveg_1 = new JRadioButton("Non-Veg");
		buttonGroup.add(rdbtnNonveg_1);
		buttonGroup.add(rdbtnNonveg_1);
		rdbtnNonveg_1.setForeground(Color.RED);
		rdbtnNonveg_1.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		panel.add(rdbtnNonveg_1);
		
		JLabel lblNewLabel_1 = new JLabel("For Pizza and Burger");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(823, 163, 153, 33);
		frmMyCaffeHb.getContentPane().add(lblNewLabel_1);
		
		
	}
}

		
		