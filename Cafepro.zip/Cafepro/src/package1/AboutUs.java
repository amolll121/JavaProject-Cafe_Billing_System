package package1;

import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JSeparator;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AboutUs {

	private JFrame frmMyCaffeHub;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AboutUs window = new AboutUs();
					window.frmMyCaffeHub.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AboutUs() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMyCaffeHub = new JFrame();
		frmMyCaffeHub.setIconImage(Toolkit.getDefaultToolkit().getImage(MainPagecaffe.class.getResource("/Images/Coffeelogo.png")));
		frmMyCaffeHub.setTitle("My Caffe Hub");
		frmMyCaffeHub.setBounds(100, 100, 1000, 655);
		frmMyCaffeHub.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMyCaffeHub.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("About Us");
		lblNewLabel.setForeground(new Color(128, 0, 128));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 27));
		lblNewLabel.setBounds(368, 54, 272, 63);
		frmMyCaffeHub.getContentPane().add(lblNewLabel);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(47, 134, 870, 21);
		frmMyCaffeHub.getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(47, 499, 870, 21);
		frmMyCaffeHub.getContentPane().add(separator_1);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMyCaffeHub.setVisible(false);
				
			}
		});
		btnNewButton.setForeground(new Color(0, 128, 0));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 22));
		btnNewButton.setBounds(96, 530, 124, 54);
		frmMyCaffeHub.getContentPane().add(btnNewButton);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setForeground(new Color(0, 128, 0));
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 22));
		btnExit.setBounds(734, 530, 124, 54);
		frmMyCaffeHub.getContentPane().add(btnExit);
		
		JLabel lblNewLabel_1 = new JLabel("\"My CaFFe Hub\" is global limited, most loved for espresso and");
		lblNewLabel_1.setForeground(new Color(220, 20, 60));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setBounds(241, 182, 666, 47);
		frmMyCaffeHub.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("disussions. Famously known As CaFFe Hub, we give best involvement to our");
		lblNewLabel_1_1.setForeground(new Color(220, 20, 60));
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(96, 239, 805, 47);
		frmMyCaffeHub.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("visitors. Our espressos are sourced from a large number of little espresso");
		lblNewLabel_1_2.setForeground(new Color(220, 20, 60));
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_2.setBounds(96, 296, 830, 47);
		frmMyCaffeHub.getContentPane().add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("growers. Furthermore, with each container, we endeavor to bring both our ");
		lblNewLabel_1_3.setForeground(new Color(220, 20, 60));
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_3.setBounds(96, 353, 793, 47);
		frmMyCaffeHub.getContentPane().add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("legacy and an extraordinary affair to life.");
		lblNewLabel_1_4.setForeground(new Color(220, 20, 60));
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_4.setBounds(96, 410, 793, 47);
		frmMyCaffeHub.getContentPane().add(lblNewLabel_1_4);
		
		
	}
}
